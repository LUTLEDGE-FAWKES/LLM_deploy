from openai import OpenAI

from .base import LanguageModel

LLAMA_ENDPOINT = "http://localhost:8000/v1"
LLAMA_API_KEY = "EMPTY"


class LlamaServer(LanguageModel):
    def __init__(self, model: str = "llama3_70b_instruct", *args, **kwargs):
        super().__init__(model, *args, **kwargs)
        self.client = OpenAI(
            base_url=LLAMA_ENDPOINT,
            api_key=LLAMA_API_KEY,
        )

    def chat(self, message: str, system_msg: str = None, json_mode: bool = False):
        if system_msg is None:
            system_msg = "You are a helpful assistant."
        messages = [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": message},
        ]
        # print(messages)
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=200,
            response_format={ "type": "json_object" },
            stop=['<|eot_id|><|start_header_id|>assistant<|end_header_id|>'],
            n=1,
            temperature=0.1,
        )
        # print(response)
        response = response.choices[0].message.content
        # print('chat completed, state:', response['state'])
        return response

    def complete(self, prompts: str):
        response = self.client.completions.create(
            model=self.model, prompt=prompts, echo=False, max_tokens=100
        )
        response = response.choices[0].text
        return response


if __name__ == "__main__":
    llama = LlamaServer("llama3_70b_instruct")
    response = llama.complete(
        "The reason of human landing on moon is that, some one found it strange behind the moon."
    )
    print(response)
